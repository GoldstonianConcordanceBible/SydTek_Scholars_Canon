# Student Records Access Control (Non-Public)

Student records are not stored in the public Canon repo.

## Storage rule
Student records must be stored in a separate private repository or an encrypted system with documented access control.

## Access rule (roles)
- Head of School
- Operations/Compliance Lead
- Academic Director (limited)
- Safeguarding Lead (incident-specific)

## Audit rule
All access changes must be logged.
