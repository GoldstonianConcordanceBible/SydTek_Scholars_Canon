# SydTek Scholars Canon (K–12)

This repository contains the **SydTek Scholars Canon** and the accreditation-ready documentation pack for SydTek Scholars (Mt. Gilead, NC).

## What’s inside
- Canon book (mission, creed, governance, academic doctrine, accountability)
- Policies pack (safeguarding, privacy, AI integrity, admissions/tuition, complaints, etc.)
- Handbooks (student/family/faculty templates)
- Curriculum scope & sequence + Hebrew Thread standards
- Assessment & outcomes (rubrics, dashboards, audits, annual reports)
- Accreditation packet (self-study narrative, standards crosswalk, evidence index)

## Privacy boundary
No student records are stored here. See: `06-student-records-private/README-ACCESS-CONTROL.md`.

## Versioning
Controlled documents include headers with owner, version, and review cycle. See `CHANGELOG.md`.
