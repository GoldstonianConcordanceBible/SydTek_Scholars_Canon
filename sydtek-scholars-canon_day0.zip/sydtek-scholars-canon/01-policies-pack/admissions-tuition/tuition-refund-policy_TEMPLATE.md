**Document Owner:** Head of School  
**Version:** v1.0  
**Effective Date:** 2026-01-28  
**Review Cycle:** Annual  
**Last Reviewed:** 2026-01-28  
**Next Review:** 2027-01-28  

---
# Tuition Refund Policy

Tuition and refund policy template.
