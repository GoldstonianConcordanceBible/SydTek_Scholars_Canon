**Document Owner:** Ops/Compliance Lead  
**Version:** v1.0  
**Effective Date:** 2026-01-28  
**Review Cycle:** Annual  
**Last Reviewed:** 2026-01-28  
**Next Review:** 2027-01-28  

---
# Parent Aup

Parent acceptable use policy template.
