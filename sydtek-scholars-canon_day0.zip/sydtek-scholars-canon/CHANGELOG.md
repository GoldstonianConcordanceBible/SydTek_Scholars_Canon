# Changelog

## v1.0 — 2026-01-28
- Initial Day 0 repo scaffolding for SydTek Scholars Canon
- Added Canon book scaffold, accreditation packet templates, policies/handbooks templates
- Added evidence index starter rows and standards crosswalk template
