**Document Owner:** Head of School  
**Version:** v1.0  
**Effective Date:** 2026-01-28  
**Review Cycle:** Annual  
**Last Reviewed:** 2026-01-28  
**Next Review:** 2027-01-28  

---
# Day 0 → Day 365 Roadmap (v1.0)

## Day 0–7
- Publish Canon repo + site repo + curriculum spine repo
- Create accreditation packet templates (narrative, crosswalk, evidence index)
- Publish transparency page

## Day 30
- Run Day-30 audit
- Publish public-safe audit memo + action list

## Day 90
- Run Day-90 audit
- Produce first outcomes baseline dashboard (aggregate)
- Publish improvement actions (public-safe)

## Quarterly
- Quarterly audits + board minutes + policy review status

## Annual
- Annual report + safeguarding summary + finance summary (public-safe)
- Canon version review + changelog update
