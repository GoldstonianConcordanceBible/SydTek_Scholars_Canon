**Document Owner:** Ops/Compliance Lead  
**Version:** v1.0  
**Effective Date:** 2026-01-28  
**Review Cycle:** Annual  
**Last Reviewed:** 2026-01-28  
**Next Review:** 2027-01-28  

---
# SydTek Scholars — Accreditation Narrative (Copy/Paste)

## 1) Institution Overview
SydTek Scholars is a Judeo-Christian K–12 education program designed to form covenant-faithful learners through academic excellence, biblical literacy, a structured Hebrew thread, and measurable outcomes.

## 2) Mission and Governance
Our mission and creed are documented in the Canon and governed through version control, board oversight, documented minutes, and conflict-of-interest disclosures.

## 3) Academic Model
Two modes:
- Homeschool-Online (family-led with SydTek curriculum, assessments, and evidence standards)
- Academy (teacher-led / hybrid as available)
Both modes share one curriculum spine, one outcomes system, and one evidence standard.

## 4) Curriculum and Instruction
The Covenant Pathway Series is our curriculum spine. Every unit includes: outcomes tags, worldview integration notes, Hebrew thread elements, assessments, and portfolio artifacts aligned to Meaning → Action → Providence.

## 5) Assessment and Outcomes
We use formative and summative assessments, portfolio rubrics, and annual outcomes summaries (aggregate). Results drive quarterly data reviews and annual improvement plans.

## 6) Student Support
We provide tiered supports (Tier 1–3), documented intervention plans, accommodation procedures, and privacy-protected recordkeeping.

## 7) Safeguarding and Safety
Safeguarding is non-negotiable: background checks, training logs, reporting protocols, incident documentation, and leadership oversight.

## 8) Technology and Privacy
We operate with data minimization, role-based access controls, approved tools governance, and AI integrity rules aligned to age bands.

## 9) Continuous Improvement
We run Day-30, Day-90, quarterly, and annual audits. Findings generate action plans with owners, deadlines, and evidence receipts.
